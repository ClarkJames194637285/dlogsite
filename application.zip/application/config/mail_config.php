<?php
define('MAIL_HOST','smtp.mailtrap.io'); //Host
define('MAIL_USERNAME','ad395209262f63'); //Username
define('MAIL_PASSWORD','8dc1df158da2ab'); //Password
define('FROM_MAIL','test@from.example.com');
define('TO_MAIL','test@to.example.com');
define('SUBJECT','パスワード通知');
define('MAIL_ENCRPT','tls'); //TLS
define('SMTP_PORT', 2525); //Port


