
<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'siteKey' => '6LcC6UsaAAAAAPv2eAh6AwMM9qv3t0y1hv7SdqAY', // 'mail', 'sendmail', or 'smtp'
    'sslkey' => '%13+m%AD%5Ea%EE%1D%DC%DC%01%CC%94%3F9%05',
    'secretKey' => '6LcC6UsaAAAAACG0XDbHHPaP55TnsVu1NdI2Wl2s'
,);
