
<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'host' => 'localhost', // 'mail', 'sendmail', or 'smtp'
    'username' => 'root',
    'password' => 'my_60_1216',
    'dbname' => 'dlogdb'
);

