<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = "smtp.lolipop.jp";
$config['smtp_port'] = 587;
$config['smtp_user'] = "info@noisy-hita-1879.boy.jp";
$config['smtp_pass'] = 'd-9mKDJWgwTUb21-';
$config['charset'] = "utf-8";
$config['mailtype'] = "html";
// $config['smtp_host'] = "smtp.lolipop.jp";
// $config['smtp_port'] = 587;
// $config['smtp_user'] = "info@noisy-hita-1879.boy.jp";
// $config['smtp_pass'] = 'd-9mKDJWgwTUb21-';
