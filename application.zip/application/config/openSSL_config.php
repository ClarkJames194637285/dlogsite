
<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'cipher' => 'aes-256-ecb', // 'mail', 'sendmail', or 'smtp'
    'key' => 'test_key'
);
