<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Home
$lang['user_title']                               = 'ユーザー設定';
