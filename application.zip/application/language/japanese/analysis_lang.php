<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// report
$lang['report_title']            = 'レポート';




//graph analysis
$lang['graph_analysis_title']            = 'グラフ分析';
$lang['filter']            = 'フィルター';
$lang['sensor']            = 'センサー';
$lang['showall']            = '全て表示する';
$lang['rearrange']            = '並び替える';
$lang['sensortype']            = 'センサータイプ';
$lang['temperature']            = '温度計';
$lang['humidity']                  =  '温湿度計';

//graph comparison

$lang['graph_comparison_title']            = 'グラフの比較';