<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Home
$lang['home']                               = 'Home';

//setting
$lang['advertising']                    = 'Advertising Notification Column';
$lang['operatingStatus']                    = 'Operating Status';
$lang['normal']                    = 'Normal';
$lang['Warning1']                    = 'Warning 1';
$lang['Warning2']                    = 'Warning 2';
$lang['offline']                    = 'Offline';
$lang['registeredSensor']                    = 'Registered Sensor';