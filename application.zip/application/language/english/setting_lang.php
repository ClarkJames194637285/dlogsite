<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// user setting
$lang['user_title']                               = 'User Setting';
