<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Home
$lang['home']                               = 'ホーム';

//setting
$lang['advertising']                    = '広告告知欄';
$lang['operatingStatus']                    = '稼働状態';
$lang['normal']                    = '正常';
$lang['Warning1']                    = '警告1';
$lang['Warning2']                    = '警告2';
$lang['offline']                    = 'オフライン';
$lang['registeredSensor']                    = '登録済センサー';


