<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// report
$lang['report_title']            = 'Report';




//graph analysis
$lang['graph_analysis_title']            = 'Graph Analysis';
$lang['filter']            = 'Filter';
$lang['sensor']            = 'Sensor';
$lang['showall']            = 'Show All';
$lang['rearrange']            = 'Rearrange';
$lang['sensortype']            = 'Sensor Type';
$lang['temperature']            = 'Temperature';
$lang['humidity']                  =  'Thermo-hygrometer';

//graph comparison

$lang['graph_comparison_title']            = 'Graph Comparison';